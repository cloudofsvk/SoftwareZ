/* This file is auto generated, version 40-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#40-Ubuntu SMP Thu May 12 22:03:46 UTC 2016"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-41"
#define LINUX_COMPILER "gcc version 5.3.1 20160413 (Ubuntu 5.3.1-14ubuntu2) "
