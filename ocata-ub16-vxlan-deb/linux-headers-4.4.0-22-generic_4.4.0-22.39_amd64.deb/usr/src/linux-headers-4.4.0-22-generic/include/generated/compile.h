/* This file is auto generated, version 39-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#39-Ubuntu SMP Thu May 5 16:53:32 UTC 2016"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-32"
#define LINUX_COMPILER "gcc version 5.3.1 20160413 (Ubuntu 5.3.1-14ubuntu2) "
