/* This file is auto generated, version 85-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#85-Ubuntu SMP Mon Feb 20 11:50:30 UTC 2017"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-56"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.4) "
