# Copyright 2016 OpenStack Foundation
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
#

"""Drop NEC plugin tables

Revision ID: e3278ee65050
Revises: 2b4c2465d44b
Create Date: 2016-02-15 18:50:56.870043

"""

# revision identifiers, used by Alembic.
revision = 'e3278ee65050'
down_revision = '2b4c2465d44b'

from alembic import op


def upgrade():
    op.drop_table('ofcnetworkmappings')
    op.drop_table('ofcportmappings')
    op.drop_table('ofcroutermappings')
    op.drop_table('ofcfiltermappings')
    op.drop_table('ofctenantmappings')
    op.drop_table('portinfos')
    op.drop_table('routerproviders')
    op.drop_table('packetfilters')
