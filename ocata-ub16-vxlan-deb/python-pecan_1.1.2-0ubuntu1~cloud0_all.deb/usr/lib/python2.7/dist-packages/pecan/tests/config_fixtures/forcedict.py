# Pecan Application Configurations
beaker = {
    'session.key': 'key',
    'session.type': 'cookie',
    'session.validate_key': '1a971a7df182df3e1dec0af7c6913ec7',
    '__force_dict__': True
}

# Custom Configurations must be in Python dictionary format::
#
# foo = {'bar':'baz'}
#
# All configurations are accessible at::
# pecan.conf
